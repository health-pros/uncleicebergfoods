(function(){
var $=function(s){return document.querySelector(s)};
var m=$('.menu'),n=$('nav');if(m)m.onclick=function(){var o=n.classList.toggle('open');m.setAttribute('aria-expanded',o)};
var pop=$('#popup'),bar=$('#sticky');
function seen(){try{return sessionStorage.getItem('uib_pop')}catch(e){return null}}
function mark(){try{sessionStorage.setItem('uib_pop','1')}catch(e){}}
function open(){if(!pop||seen())return;pop.classList.add('open');mark();var f=pop.querySelector('input');f&&f.focus()}
function close(){pop.classList.remove('open')}
if(pop){setTimeout(open,25000);document.addEventListener('mouseout',function(e){if(e.clientY<0)open()});
pop.addEventListener('click',function(e){if(e.target===pop)close()});
pop.querySelector('.x').onclick=close;document.addEventListener('keydown',function(e){if(e.key==='Escape')close()});
document.querySelectorAll('[data-open-popup]').forEach(function(b){b.onclick=function(e){e.preventDefault();pop.classList.add('open')}})}
if(bar){window.addEventListener('scroll',function(){bar.classList.toggle('show',scrollY>700&&!bar.dataset.x)},{passive:true});
bar.querySelector('.c').onclick=function(){bar.dataset.x=1;bar.classList.remove('show')}}
document.querySelectorAll('.checks input').forEach(function(c,i){c.id='c'+i;try{c.checked=localStorage.getItem('uib_c'+i)==='1'}catch(e){}
c.onchange=function(){try{localStorage.setItem('uib_c'+i,c.checked?'1':'0')}catch(e){}}});
var cp=$('#copy');if(cp)cp.onclick=function(){var t=[].map.call(document.querySelectorAll('.checks label'),function(l){return '- '+l.textContent.trim()}).join('\n');
navigator.clipboard&&navigator.clipboard.writeText(t).then(function(){cp.textContent='Copied'})};
})();
